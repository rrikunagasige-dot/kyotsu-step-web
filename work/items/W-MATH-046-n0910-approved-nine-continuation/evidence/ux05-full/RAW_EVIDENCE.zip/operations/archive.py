from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib,json
base=Path('/tmp/w046-ux05-full');repo=Path('/workspace/scratch/6ff917b2ec4a/w046-ux05-full');dest=repo/'work/items/W-MATH-046-n0910-approved-nine-continuation/evidence/ux05-full';files={}
def add(path,prefix):
 p=Path(path)
 if p.is_file():files[prefix]=p
 elif p.exists():
  for f in p.rglob('*'):
   if f.is_file():files[prefix+'/'+str(f.relative_to(p))]=f
for p in base.iterdir():
 if p.is_file() and p.suffix in ['.json','.md','.mjs','.py','.log'] and p.name not in ['approval-files.json','source-upload.json','checkpoint-paths.json']:add(p,'operations/'+p.name)
for n in ['r04','r07','r07-final']:add(base/n,n)
for n,path in [('first-n09','/tmp/w046-ux05-full-browser-n09-final'),('first-n10','/tmp/w046-ux05-full-browser-n10-final'),('final-n09','/tmp/w046-ux05-release-browser-n09'),('final-n10','/tmp/w046-ux05-release-browser-n10'),('cold-start-n09','/tmp/w046-ux05-release-browser-n09-cold-start'),('cold-start-n10','/tmp/w046-ux05-release-browser-n10-cold-start'),('migration','/tmp/w046-ux05-release-migration')]:add(path,n)
add(base/'publisher','publisher')
data={n:p.read_bytes() for n,p in files.items()}
manifest={n:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}for n,b in data.items()}
with ZipFile(dest/'RAW_EVIDENCE.zip','w',ZIP_DEFLATED,compresslevel=9)as z:
 z.writestr('README.md','''# UX05本適用の原検証証拠\n\n最終アプリsource: 691d3d160493bf684ca8a31a22476d31d98caeec\n原アプリsource（余白指摘前）: ba2e1d8b00c7d7eb113cb9d828ec8b495adcf444\n\nfinal-n09/final-n10 は4幅の実DOM、全未回答/誤答/完成packetとauto/history/lifecycle、320/1440の変更23node原PNG。first-*は初回検査と余白欠陥の原画像。cold-startは状態採取前timeoutの原FAIL。上書き合格にしていない。\n\nr04は既存CODE原結果/可視snapshot/意味request/非作者応答/採否、r07は差戻し時、r07-finalは新source実画像とgeometryに束縛した非作者応答/import。operationsは既存CODEの薄い呼出し、関連回帰、型/build、公開準備、source報告。migrationは合成テストledgerによる24cases、実利用者データ・正式Storeイベントは含まない。\n\n再実行はrepoの当該sourceをclean checkoutし固定依存を用意、operations/browser.mjsへW046_SOURCE_ROOT/W046_EXPECTED_SHA/W046_OUTPUTを明示する。各unitの独自portを使用する。公開は実行しない。Store26イベント欠落の本人特例継続であり、正式台帳PASSEDは認定していない。\n\nファイルのbyte証拠はMANIFEST.json。本人最終受入、Gold、fit、公開承認を作成しない。\n''')
 z.writestr('MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
 for n,b in data.items():z.writestr(n,b)
print(len(files),(dest/'RAW_EVIDENCE.zip').stat().st_size)
