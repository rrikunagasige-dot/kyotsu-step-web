import fs from 'node:fs';
import {operate} from '/workspace/scratch/6ff917b2ec4a/w046-ux05-full/tools/textbook/operations.mjs';
const out='/tmp/w046-ux05-full/r04';
for(const [code,suffix] of [['n09','b'],['n10','a']]){const req=JSON.parse(fs.readFileSync(`${out}/${code}-meaning-requests.json`));const responses=JSON.parse(fs.readFileSync(`${out}/${code}-responses-${suffix}.json`));const reviews=req.reviews.map(q=>({id:q.id,request:q.request,response:responses.reviews.find(r=>r.id===q.id).response}));const result=operate('solution-review',{reviews});fs.writeFileSync(`${out}/${code}-meaning-import.json`,JSON.stringify(result,null,2));console.log(code,result.status,result.findings);if(result.status==='FAIL')process.exitCode=1;}
