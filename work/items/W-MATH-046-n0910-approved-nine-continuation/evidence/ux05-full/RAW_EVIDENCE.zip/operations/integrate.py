from pathlib import Path
import json,hashlib,shutil
r=Path('/workspace/scratch/6ff917b2ec4a/w046-ux05-full');p=r/'work/items/W-MATH-043-n0910-restart/NODE_DESIGN.json';d=json.loads(p.read_text());directory=r/'src/data/textbook/math/numbers'
for code,rev in [('n09',7),('n10',4)]:
 src=directory/(code+'ConstructionCompiled.json');dst=directory/(code+f'ConstructionCompiledR{rev}.json')
 if dst.exists():assert dst.read_bytes()==src.read_bytes()
 else:shutil.copyfile(src,dst)
u9=json.load(open('/tmp/w046-ux05-full/n09-unit.json'));u10=json.load(open('/tmp/w046-ux05-full/n10-unit.json'))
old9=d['units'][0];oldmap={n['nodeId']:n for n in old9['nodes']};assert all(n==oldmap[n['nodeId']] for n in u9['nodes'] if n['nodeId'] in ['n09-q01-negative','n09-01'])
d['units']=[u9,u10];d['ux04Pilot']=False;d['ux03Pilot']=False;d['ux05Full']=True;d['proposalId']='P-W046-UX-05';d['status']='APPROVED_CONTENT_MATERIALIZED_PENDING_VERIFICATION';d['revision']=8;d['materializationNote']='Accepted N09r7 representative is immutable; remaining UX05 content uses N09r8 and N10r5, with exact native migration edges.'
p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');sha=hashlib.sha256(p.read_bytes()).hexdigest();q=r/'tools/textbook/transformation/nested-lesson.mjs';s=q.read_text();s=s.replace("export const REVIEWED_NESTED_DESIGN = 'f73e64fae94c45349b7c0ceb95cdca1e422342124b738cc684c8f76b0d8ca2f8';",f"export const REVIEWED_NESTED_DESIGN = '{sha}';\nconst UX05_PILOT_REVIEWED_NESTED_DESIGN = 'f73e64fae94c45349b7c0ceb95cdca1e422342124b738cc684c8f76b0d8ca2f8';");s=s.replace('[REVIEWED_NESTED_DESIGN, UX04_REVIEWED_NESTED_DESIGN','[REVIEWED_NESTED_DESIGN, UX05_PILOT_REVIEWED_NESTED_DESIGN, UX04_REVIEWED_NESTED_DESIGN');q.write_text(s);print('native design',sha)
