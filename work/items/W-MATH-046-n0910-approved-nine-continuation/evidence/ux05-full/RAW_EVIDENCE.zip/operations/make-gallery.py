from pathlib import Path
import json,base64,html,hashlib
root=Path('/workspace/scratch/6ff917b2ec4a/w046-ux05-full');out=root/'work/items/W-MATH-046-n0910-approved-nine-continuation/evidence/ux05-full';source='691d3d160493bf684ca8a31a22476d31d98caeec';parts=['<!doctype html><html lang="ja"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>UX05 本適用 実画面一覧</title><style>body{font:16px/1.7 system-ui,sans-serif;margin:auto;max-width:1150px;padding:24px;color:#18354a;background:#f6f5f0}h1{font-size:24px}section{background:white;border:1px solid #c2d2dd;border-radius:8px;padding:16px;margin:24px 0}.pair{display:flex;align-items:flex-start;gap:20px;flex-wrap:wrap}figure{margin:8px 0;max-width:100%}img{max-width:100%;height:auto;border:1px solid #c6d1dc}figcaption{font-weight:600}code{overflow-wrap:anywhere}summary{cursor:pointer;font-weight:600}p{margin:8px 0}</style><h1>UX05 残り23箇所の修正・実画面一覧</h1><p>承認済み案の本適用。中高生が式の変形・条件・根拠を判断して進むように修正。代表確認済みの2箇所は保持しています。</p><p>各画像は固定コードからの実画面です。320pxは未回答→完成、1440pxは折り畳み内。自動まとめには完成画面だけを掲載しています。</p><p>対象コード：<code>'+source+'</code>。公開後の本人総チェックは別工程です。</p>'];manifest=[]
for code in ['n09','n10']:
 report=json.load(open('/tmp/w046-ux05-full/'+code+'-author-report.json'));ids=report.get('changedNodeIds',report.get('changedNodes'));compiled=json.load(open(root/('src/data/textbook/math/numbers/'+code+'ConstructionCompiled.json')));nodes={n['nodeId']:n for n in compiled['nodeDesign']};directory=Path('/tmp/w046-ux05-release-browser-'+code)
 for nodeId in ids:
  n=nodes[nodeId];parts.append('<section><h2>'+html.escape(nodeId)+'</h2>')
  for width in [320,1440]:
   if width==1440:parts.append('<details><summary>1440pxで確認</summary>')
   parts.append('<div class="pair">')
   states=['initial','complete']if n['parts']else['auto-complete']
   for state in states:
    p=directory/f'{width}-{nodeId}-{state}.png';b=p.read_bytes();manifest.append({'nodeId':nodeId,'width':width,'state':state,'sha256':hashlib.sha256(b).hexdigest(),'path':str(p)});label='未回答'if state=='initial'else'完成';parts.append('<figure><figcaption>'+str(width)+'px・'+label+'</figcaption><img loading="lazy" alt="'+html.escape(nodeId+' '+label)+'" src="data:image/png;base64,'+base64.b64encode(b).decode()+'"></figure>')
   parts.append('</div>')
   if width==1440:parts.append('</details>')
  parts.append('</section>')
parts.append('</html>');(out/'REVIEW_GALLERY.html').write_text(''.join(parts));(out/'GALLERY_MANIFEST.json').write_text(json.dumps({'sourceSHA':source,'images':manifest},indent=2)+'\n');print('gallery',len(manifest),'images', (out/'REVIEW_GALLERY.html').stat().st_size)
