import json,pathlib,copy,hashlib
root=pathlib.Path('/workspace/scratch/6ff917b2ec4a/w046-ux05-full');out=pathlib.Path('/tmp/w046-ux05-full')
native=json.loads((root/'work/items/W-MATH-043-n0910-restart/NODE_DESIGN.json').read_text());unit=copy.deepcopy(native['units'][0]);before=copy.deepcopy(unit)
proposal=json.loads((root/'work/items/W-MATH-046-n0910-approved-nine-continuation/evidence/ux05-proposal/N09_DESIGN.json').read_text());approved={n['nodeId']:n for n in proposal['nodes']};pilot={'n09-q01-negative','n09-01'}
def rule(kind,template):return {'kind':kind,'template':template,'partKeys':[],'requiresCorrectKeys':[]}
# Literal typed presentation of approved general rules. This is input materialization,
# not a new math engine or an alteration of any particular expected answer.
rules={
'n09-q02-negative-square':[rule('text','積の平方と平方根の定義を使います。'),rule('math',r'(uv)^2=u^2v^2'),rule('math',r'(\sqrt a)^2=a\quad(a\ge0)')],
'n09-q04-negative':[rule('text','平方根記号は非負の平方根を表します。')],
'n09-q07-negation':[rule('math',r'|u|=\begin{cases}u&(u\ge0)\\-u&(u<0)\end{cases}')],
'n09-decimal-method':[rule('text','中項は異なる項どうしの積が二つ分です。'),rule('math',r'(A+B)^2=A^2+AB+BA+B^2'),rule('math',r'=A^2+2AB+B^2'),rule('math',r'\left(\frac pq\right)^2=\frac{p^2}{q^2}\quad(q\ne0)')],
'n09-q10-reject-truncation':[rule('math',r'x=n+r,\quad n\in\mathbb Z,\quad0\le r<1')],
'n09-q13-reverse':[rule('text','負の数を掛けると、大小の向きが変わります。')],
'n09-q14-positive-remainder':[rule('math',r'r=x-n')],
'n09-q14-negative-remainder':[rule('math',r'r=x-n')],
}
changed=[]
for n in unit['nodes']:
 p=approved[n['nodeId']];nid=n['nodeId']
 if p['decision']!='CHANGE' or nid in pilot:continue
 changed.append(nid);old=copy.deepcopy(n);oldparts={x['key']:x for x in old['parts']};n['leadParts']=[dict(type='text',text=p['initialLead'])];n['leadPlainText']=p['initialLead'];n['assumptions']=copy.deepcopy(p['initialConditions']);assert n['assumptions']==old['assumptions']
 n['prerequisiteNodeIds']=p['proposedPrerequisiteNodeIds'];n['requiredResultRefs']=p['proposedRequiredResultRefs'];n['partOrder']=[x['key'] for x in p['parts']];n['parts']=[]
 for a in p['parts']:
  if a['decision']=='KEEP':part=copy.deepcopy(oldparts[a['key']])
  else:
   part={k:copy.deepcopy(a[k]) for k in ['key','id','kind','role','prompt','expected','choices']}
   if part['key']=='differenceRelationUX05':part['role']='relation'
   part['learningAction']=a['thinkingOperation'];part['sourceRefs']=[v['sourceBlockId'] for v in old['sourceCoverage']]
   for c in part['choices']:
    c.pop('correct',None);c['misconception']='正答' if c['value']==part['expected'] else c['feedback']
   part['mathAssertion']=dict(kind='requires-semantic-review',expected=part['expected'],codeSupported=False,reviewStatus='NEEDS_AI_REVIEW',rationale=a['thinkingOperation']+'。数学CODE未対応は非作者意味審査へ接続。',sourceRefs=part['sourceRefs'])
  n['parts'].append(part)
 n['classification']='NEW_CONSTRUCTION' if n['parts'] else 'KEEP_EXPOSITION'
 n['rows']=[]
 for i,r in enumerate(rules.get(nid,[])):
  r=copy.deepcopy(r);r.update(id=nid+'::ux05-given-'+str(i+1).zfill(2),certifiedFrom=n['requiredResultRefs'])
  if r['kind']=='math':r['mathGroupId']=n['rows'][-1]['mathGroupId'] if r['template'].startswith('=') else nid+'-ux05-given-'+str(i+1).zfill(2)
  n['rows'].append(r)
 for r in p['rows']:
  r=copy.deepcopy(r);r['certifiedFrom']=n['requiredResultRefs'];n['rows'].append(r)
 # Keep meaningful mathematical subjects across helper calculations and returns.
 # Q08 row2 starts the integer square; leading '=' rows continue only that object.
 if nid.endswith('q08-left-square') or nid.endswith('q08-right-square'):
  r=n['rows'][-1];assert r['template'].startswith('1.4') and 'mirror:' in r['template']
 if nid=='n09-q03-inside':
  ref='n09-q01-negative-result';assert ref in n['requiredResultRefs']
  n['terminalRecord']['prose']='先に認定した負の候補の平方を参照し、根号の中を16へ直しました。次に非負の平方根を選びます。'
  n['terminalRecord']['proseParts']=[dict(type='text',text=n['terminalRecord']['prose'])]
 if nid=='n09-decimal-method':
  n['sourceExtraDisposition']['reason']='両候補の平方計算と大小比較が認定された後で補助表を表示し、未回答の平方値を先出ししない。'
 n['terminalRecord']['formulas']=p['terminalFormulas'];n['terminalRecord']['requiresCorrectKeys']=n['partOrder'];n['terminalRecord']['certifiedFrom']=n['requiredResultRefs']
 for cov in n['sourceCoverage']:
  cov['disposition']='REPLACE';cov['targetRefs']=[n['leadId']]+[r['id'] for r in n['rows']]+[nid+'::terminal'];cov['reason']='承認済みUX05の完全解法と主判断へ対応。原問題・条件・結論を保持し、既認定値の写し/基本操作の細分化を減らす。'
 n['ux05FullDisposition']=dict(proposal='P-W046-UX-05',completeSolution=p['completeSolution'],partOrder=n['partOrder'],approval='本人のUX05明示承認＋代表細部OKにより残りCHANGEへ限定適用。')
unit['fromRevision']=7;unit['toRevision']=8;unit['counts']=dict(sourceNodes=len(unit['nodes']),constructionParents=sum(bool(n['parts']) for n in unit['nodes']),parts=sum(len(n['parts']) for n in unit['nodes']),automaticNodes=sum(not n['parts'] for n in unit['nodes']))
# Compare against actual r7, rather than reusing the r6 approval's retirement table.
newparts={p['id']:p for n in unit['nodes'] for p in n['parts']};oldparts={p['id']:p for n in before['nodes'] for p in n['parts']};mapping=[]
for n in before['nodes']:
 for p in n['parts']:
  dest=newparts.get(p['id']);keep=dest is not None
  if keep:assert dest==p,('KEEP_CONTRACT_CHANGED',p['id'])
  mapping.append(dict(oldPartId=p['id'],decision='KEEP' if keep else 'RETIRE',newPartId=p['id'] if keep else None,meaning='同じ型/問い/全候補/正答/根拠の対象。新版未解決gateより先では保留。' if keep else '旧R7snapshot/出所付きarchiveへ原recordを保管。新しい意味へaliasしない。'))
newids=[id for id in newparts if id not in oldparts]
counts=dict(nodes=len(unit['nodes']),pilotUnchanged=2,keepNodesUnchanged=25,changedNodes=len(changed),oldParts=len(oldparts),keepParts=sum(m['decision']=='KEEP' for m in mapping),retireParts=sum(m['decision']=='RETIRE' for m in mapping),newParts=len(newids),targetParts=len(newparts))
assert counts==dict(nodes=41,pilotUnchanged=2,keepNodesUnchanged=25,changedNodes=14,oldParts=48,keepParts=34,retireParts=14,newParts=9,targetParts=43),counts
for old,new in zip(before['nodes'],unit['nodes']):
 if old['nodeId'] not in changed:assert old==new,('UNAPPROVED_NODE_CHANGE',old['nodeId'])
# Six approved necessary calculations stay exact; comparisons and references are untouched.
for nid,prefix in [('n09-p001-q08-left-square','L'),('n09-p001-q08-right-square','R')]:
 n=next(x for x in unit['nodes'] if x['nodeId']==nid);old=next(x for x in before['nodes'] if x['nodeId']==nid)
 for i in [1,2,3]:assert next(p for p in n['parts'] if p['key']==prefix+str(i))==next(p for p in old['parts'] if p['key']==prefix+str(i))
path=out/'n09-unit.json';path.write_text(json.dumps(unit,ensure_ascii=False,indent=2)+'\n')
report=dict(unitId=unit['unitId'],fromRevision=7,toRevision=8,counts=counts,changedNodeIds=changed,oldPartMapping=mapping,newPartIds=newids,baseline='a1b6 UX05 pilot fine detail approved',inputProposalSHA256=hashlib.sha256((root/'work/items/W-MATH-046-n0910-approved-nine-continuation/evidence/ux05-proposal/N09_DESIGN.json').read_bytes()).hexdigest(),nativeUnitSHA256=hashlib.sha256(path.read_bytes()).hexdigest(),limitations='単元入力materializationと構造集計のみ。R04既存CODE・非作者意味審査・R07実装後検証はrootへ接続。製品/正式Work/Git/Store未編集。')
(out/'n09-author-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
md=['# UX05 N09 残14node native materialization','元root: w046-ux05-full。AGENTS/工程入口/承認N09_DESIGNを読取。代表2nodeは通常公式表示補修済みの実byte契約を全保持。KEEP25も全object一致。残14CHANGEだけをnative units[0]へ適用。','N09 from7→to8。R7 snapshotはrootが不変保存し、過去履歴のsourceとして使う。公開は別承認。','```json',json.dumps(counts,ensure_ascii=False,indent=2),'```','## 変更と意味根拠']
for nid in changed:
 p=approved[nid];n=next(n for n in unit['nodes'] if n['nodeId']==nid)
 md+=['','### '+nid,p['reason'],'完成解法：'+p['completeSolution'],'初期本文：'+p['initialLead'],'知識/result前提：'+json.dumps(n['requiredResultRefs'],ensure_ascii=False),'主判断：'+json.dumps([dict(id=p['id'],operation=p.get('learningAction')) for p in n['parts']],ensure_ascii=False),'具体rows/全候補/誤答理由はn09-unit.jsonの当nodeを正本参照。']
md+=['','## 保存・原資料・表示の境界','R7の48part全件をキーとnative契約で照合し34KEEP/14RETIREを確定、9NEWは未回答・aliasなし。KEEP34のpart objectは元R7と厳密一致。pilotのfactorisedFormUX05/factorZeroConditionUX05もKEEPへ含む。','sourcePath/sourceSha256/sourceBaseCommit、原Word対応sourceBlockId/sourceMeaning/sourcePhase、extra/図の原データを保持。変更nodeのsourceCoverage.targetRefsだけを新行へ再対応。Q08補助表は既存のn09-08完了後gateを保持し、認定part数に依存する古い理由文だけ修正。','一般公式はmath型と説明textへ明示し、raw TeXを本文へ置かない。新しいdifferenceRelationUX05のnative roleはrelationとし、既存compilerが不等号軸を認識する型へ束縛（設問/値/候補は同じ）。Q08は整数平方の式から継続=を使い、小数平方へ戻る行は完全左辺を持つ。mirrorは同nodeのL1/L2またはR1/R2が認定済みの行だけ。q03の既認定16参照は明示result/prerequisiteを追加し、他nodeの値をmirrorに偽装しない。','Q08 L1/L2/L3/R1/R2/R3の全数学契約objectを保持し、比較C/D・root境界node等KEEP25は全object一致。','これは私が作者の候補であり独立数学PASSを主張しない。B非作者の原資料/数学/先出し/型/主語とroot統合審査を受ける。','## R7全part対応','```json',json.dumps(mapping,ensure_ascii=False,indent=2),'```','NEW：'+json.dumps(newids,ensure_ascii=False),'unit SHA256 '+report['nativeUnitSHA256']]
(out/'n09-author-report.md').write_text('\n\n'.join(md)+'\n')
print(json.dumps(report['counts']));print('UNIT_SHA256',report['nativeUnitSHA256'])
