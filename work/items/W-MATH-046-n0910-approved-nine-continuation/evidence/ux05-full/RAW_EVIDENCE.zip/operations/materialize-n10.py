import json,copy,hashlib,pathlib
root=pathlib.Path('/workspace/scratch/6ff917b2ec4a/w046-ux05-full');out=pathlib.Path('/tmp/w046-ux05-full')
source=root/'work/items/W-MATH-043-n0910-restart/NODE_DESIGN.json';proposal=root/'work/items/W-MATH-046-n0910-approved-nine-continuation/evidence/ux05-proposal/N10_DESIGN.json'
design=json.loads(source.read_text());plan=json.loads(proposal.read_text());unit=copy.deepcopy(json.loads((out/'n10-baseline-unit.json').read_text()));baseline=copy.deepcopy(unit);approved={n['nodeId']:n for n in plan['nodes']}
M=lambda s:{'type':'math','latex':s};T=lambda s:{'type':'text','text':s}
conditions={
'n10-q10-coefficients':[[T('直前で'),M(r'\sqrt8=2\sqrt2'),T('、'),M(r'\sqrt{50}=5\sqrt2'),T('を確定済み。')]],
'n10-q11-formula':[[T('既習公式：'),M(r'(A-B)^2=A^2-2AB+B^2')]],
'n10-q13-identity':[[T('既習の分配法則と和と差の積を使う。')]],
'n10-17':[[M(r'c=\sqrt3-\sqrt2\ne0'),T('、元分母'),M(r'\sqrt3+\sqrt2>0'),T('。')]],
'n10-q19-distribute':[[T('対象は分子'),M(r'\sqrt3(\sqrt3-\sqrt2)'),T('。')]],
'n10-19':[[T('前の分母計算で'),M(r'(\sqrt3)^2=3'),T('、分母'),M('=1'),T('を確定済み。')]],
'n10-q20-factor':[[T('元分母'),M(r'2+\sqrt3>0'),T('。この手順の指定は'),M('c>0'),T('。逆符号の有効な別解を数学的に不可能とはしない。')]],
'n10-20':[[M(r'c=2-\sqrt3\ne0'),T('を確定済み。比較で'),M(r'2^2=4'),T('、'),M(r'(\sqrt3)^2=3'),T('も確定済み。')]],
'n10-q21-expand':[[T('既習公式'),M('(A-B)^2=A^2-2AB+B^2'),T('。'),M('2^2=4'),T('、'),M(r'(\sqrt3)^2=3'),T('は因子の非零性の比較で確定済み。')]],
}
expressions={'collectedExpressionUX05':'2*sqrt(2)+5*sqrt(2)','distributedNumeratorUX05':'sqrt(3)*(sqrt(3)-sqrt(2))','positiveComparisonLeftSquareUX05':'2**2','positiveComparisonRootSquareUX05':'sqrt(3)**2','rationalisedFractionUX05':'(2-sqrt(3))**2/(2**2-sqrt(3)**2)'}
for node in unit['nodes']:
 p=approved[node['nodeId']]
 if p['decision']=='KEEP':continue
 nid=node['nodeId'];old=copy.deepcopy(node);oldparts={p['key']:p for p in old['parts']}
 node.update(classification=p['classification'],leadParts=[T(p['learnerLead'])],leadPlainText=p['learnerLead'],assumptions=copy.deepcopy(p['learnerAssumptions']),assumptionParts=conditions[nid],prerequisiteNodeIds=copy.deepcopy(p['prerequisiteNodeIds']),requiredResultRefs=copy.deepcopy(p['requiredResultRefs']),partOrder=copy.deepcopy(p['partOrder']))
 node['parts']=[]
 for part in p['parts']:
  if part['decision']=='KEEP':node['parts'].append(copy.deepcopy(oldparts[part['key']]));continue
  new={k:copy.deepcopy(part[k]) for k in ['key','id','role','kind','expected','prompt']};new['choices']=[]
  for choice in part['choices']:
   new['choices'].append({k:copy.deepcopy(v) for k,v in choice.items() if k in ['value','kind','latex','display','mathLines','feedback','misconception']})
  new['learningAction']=part['learningOperation'];new['sourceRefs']=copy.deepcopy(node['sourceRefs'])
  expression=expressions.get(part['key'])
  if part['key']=='signedMiddleTermUX05':expression='-2*sqrt(2)*sqrt(3)' if nid=='n10-q11-formula' else '-2*2*sqrt(3)'
  new['mathAssertion']={'kind':'exact-evaluation' if expression else 'requires-semantic-review','expected':part['expected'],'reviewStatus':'PENDING_CODE' if expression else 'NEEDS_AI_REVIEW','sourceRefs':copy.deepcopy(node['sourceRefs']),'rationale':'CODEは閉じた有限候補の値照合のみ。根号対象と公式・相殺する項の意味対応は別の非作者審査を要し、数値一致だけで教授契約を証明しない。'}
  if expression:new['mathAssertion']['expression']=expression
  else:new['mathAssertion']['codeSupported']=False
  node['parts'].append(new)
 node['rows']=copy.deepcopy(p['rows'])
 # Every complete left side denotes a distinct mathematical target. Only leading
 # = continuations inherit the same relation axis; no auxiliary false chains.
 current=None
 for i,row in enumerate(node['rows']):
  if row.get('mathGroupId') is None:row.pop('mathGroupId',None)
  if row['kind']=='math':
   if not row['template'].lstrip().startswith('=') or current is None:current=nid+'-ux05-group-'+str(i+1)
   row['mathGroupId']=current
  else:row.pop('mathGroupId',None)
  row['certifiedFrom']=list(dict.fromkeys(node['requiredResultRefs']+row.get('certifiedFrom',[])))
 node['terminalRecord']=copy.deepcopy(old['terminalRecord'])
 for field in ['formulas','requiresCorrectKeys','certifiedFrom']:node['terminalRecord'][field]=copy.deepcopy(p['terminalRecord'][field])
 # Old terminal copy is displayed only after the new complete gate, never used
 # as a substitute for the new answers; source phrasing is retained otherwise.
 node['assertions']=[{'partKey':part['key'],**copy.deepcopy(part['mathAssertion'])} for part in node['parts'] if part.get('mathAssertion')]
 for coverage in node['sourceCoverage']:
  coverage.update(targetRefs=[node['leadId']]+[r['id'] for r in node['rows']]+[nid+'::terminal'],disposition='REPLACE',reason='承認済みUX05：'+p['purpose']+' 必要な元の条件・根拠・演算は現行導出へ残し、主判断と必要計算の位置を非作者がsourceMeaningと照合する。')
 node['ux05Disposition']={'proposal':'P-W046-UX-05','completeSolution':p['completeHoleFreeSolution'],'oldPartMapping':p['oldPartDecisions'],'crossNodeCertifiedResults':p['crossNodeCertifiedResults'],'newPartIds':[a['id'] for a in p['parts'] if a['decision']=='NEW']}
 node['migration']={'status':'EXPLICIT_UX05_PART_MAPPING','mappingRef':'P-W046-UX-05:N10_DESIGN.oldPartDecisions','policy':'同意味KEEPは原記録を保持。RETIRE11は旧r4の原保存/履歴へ。NEW8は未回答、P/Q/Kからのaliasなし。前提は新版で再評価。'}
unit['fromRevision']=4;unit['toRevision']=5;unit['counts']={'sourceNodes':len(unit['nodes']),'constructionParents':sum(bool(n['parts']) for n in unit['nodes']),'parts':sum(len(n['parts']) for n in unit['nodes']),'automaticNodes':sum(not n['parts'] for n in unit['nodes'])}
# Author integrity checks: these compare independent baseline and approved maps,
# not product tests or substitutes for the existing compiler/finite/renderer CODE.
base_nodes={n['nodeId']:n for n in baseline['nodes']};new_nodes={n['nodeId']:n for n in unit['nodes']}
kept=[n['nodeId'] for n in plan['nodes'] if n['decision']=='KEEP'];changed=[n['nodeId'] for n in plan['nodes'] if n['decision']=='CHANGE']
assert len(kept)==36 and len(changed)==9 and unit['counts']['parts']==60
assert all(base_nodes[k]==new_nodes[k] for k in kept)
oldparts={p['id']:p for n in baseline['nodes'] for p in n['parts']};newparts={p['id']:p for n in unit['nodes'] for p in n['parts']}
keepids=[x['oldId'] for x in plan['oldPartDecisions'] if x['action']=='KEEP'];retired=[x['oldId'] for x in plan['oldPartDecisions'] if x['action']=='RETIRE_ARCHIVE_ONLY'];newids=plan['newPartIds']
assert len(keepids)==52 and len(retired)==11 and len(newids)==8
assert all(oldparts[k]==newparts[k] for k in keepids)
assert set(newparts)==set(keepids+newids) and not set(retired)&set(newparts)
(out/'n10-unit.json').write_text(json.dumps(unit,ensure_ascii=False,indent=2)+'\n')
report={'status':'MATERIALIZED_PENDING_EXISTING_CODE_AND_NONAUTHOR_REVIEW','author':'/root/w046_render_review','baselineSourceCommit':'a1b6 (root-reported; root binds full SHA)','proposalSHA256':hashlib.sha256(proposal.read_bytes()).hexdigest(),'baselineUnitSHA256':hashlib.sha256(json.dumps(baseline,ensure_ascii=False,sort_keys=True).encode()).hexdigest(),'unitFileSHA256':hashlib.sha256((out/'n10-unit.json').read_bytes()).hexdigest(),'revisions':{'from':4,'to':5},'counts':unit['counts'],'changedNodes':changed,'keptNodes':kept,'keepPartIds':keepids,'retiredPartIds':retired,'newPartIds':newids,'mapping':plan['oldPartDecisions'],'scope':'tmp単元候補のみ。製品/共有NODE_DESIGN/Store/Gitは未変更。既存shared rendererは変更しない。','semantics':{'keepBoundary':'36KEEP nodeと52KEEP partはbaseline native object完全一致。H07正性→平方→同定、積商の証明、原値/図/収録順/既存source refsを保護。','q20q21':'初回平方2²=4/(√3)²=3をq20で問い、terminal resultへ記録。n10-20/q21にはq20 resultの実requiredResultRefsとprerequisiteNodeIdsを付与。旧P/Q/KはARCHIVE_ONLY、新平方と符号込み中項へaliasしない。','cancellation':'相殺組はtext enum一値、候補mathLinesで二項の境界を表示、足場ownkey hide後に具体展開と平方差を通常mathASTへする。','formulaAndGrouping':'一般公式と確定済み数式条件はassumptionPartsのtyped mathへ。完全左辺は別group、先頭=だけ継続。','finite':'7新math partは既存exact closed評価へ接続、相殺enumはrequires-semantic-review。数値候補PASSと学習意味のPASSを区別。','migrationCaution':'新gate/数学条件の文言変更があるKEEP partも、局所の問い/型/全候補/対象演算は完全同一。rootの明示mappingにより保持し、NEW前提を飛ばさない。','normalDisplay':'共有rendererは本人確認済みのまま使用し、各node専用の44px回避策を増やさない。'}}
(out/'n10-author-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
md=['# UX05 N10全適用 作者報告','',json.dumps(report['counts'],ensure_ascii=False),'', '9CHANGE/36KEEP、旧63=52KEEP/11RETIRE＋8NEW→60parts。from4→to5。共有source/Store/Git未編集。','']+[f'- **{k}**: {v}' for k,v in report['semantics'].items()]+['','## 変更と適用','','|node|主判断/適用|','|---|---|']+[f"|{p['nodeId']}|{p['purpose']}|" for p in plan['nodes'] if p['decision']=='CHANGE']+['','## 全旧part対応','','|旧id|処理|新版id|','|---|---|---|']+[f"|{x['oldId']}|{x['action']}|{x['newId'] or 'なし（旧版保存）'}|" for x in plan['oldPartDecisions']]+['','既存CODEの実行/非作者意味審査/実browser/厳密移行はroot統合で別途確認。上の作者整合assertは製品テストPASSの代用ではない。']
(out/'n10-author-report.md').write_text('\n'.join(md)+'\n');print(report['unitFileSHA256'],unit['counts'])
