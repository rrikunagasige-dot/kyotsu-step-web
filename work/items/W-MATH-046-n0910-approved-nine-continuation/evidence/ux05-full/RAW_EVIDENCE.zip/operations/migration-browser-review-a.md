# UX05 full migration browser collector 非作者レビュー A

対象 `/tmp/w046-ux05-full/migration-browser.mjs` SHA256 `f0f5b94badd0c5cf3e45156e60bf7d5dced7ae524dc1115e1a90bddf8d10ab63`。root collectorをAが読取。新runは私から行っていない。

初回15casesで新しいN10pilot同revision別hash→fullR4→R5分岐とstale-key/resetの実操作が不足していたため報告した。補修版はN10pilot一件と、N09sourceR7/targetR8・N10sourceR4/targetR5それぞれのmain reset空/1回答後とstale dedicatedの8件を追加し、24caseへ拡張した。

sourceSHA/expected SHA・前後manifest/最終HEAD・scriptHash、自spawn server、実Main/Math italic font、HTTP/network/abort原記録、served compiledHashを拘束する。未知current hashと未来revisionはalertだけでなく全storage不変を要求する。case合格は実UIの再開/解答と保存JSONを読んで判断し、fixture ledgerを実学習記録や正式Storeイベントとは呼ばない。

新edgeのN09r7/r6/r5/r4 main/dedicated、N10 fullR4 main/dedicated、pilotR4同revision鎖、旧legacy7、未知4、reset8を対象とする。sourceの旧native ledger全体をmain archiveへdeepEqualしてRETIRE原記録も確認し、現行KEEPは全record metadataを照合する。必要な新しい回答数、既存KEEPの再回答禁止、旧版7/6/5/4の試し解答保存byte不変（legacy3は既存cursor差を区別）も持つ。

## 追加補足待ち

resetのonlyInitial早期returnでは、後段のdedicated不変照合を通らない。現在key(c)はnew main resetへ置換が正当なので除外したうえで、旧source/他dedicated keyのbyte不変をreturn前に確認する補足をrootへ依頼した。post-reset ledger.processedEventIdsがnew main ledgerのものと一致することも、旧event復活を避ける確認として併記依頼した。新caseの追加は不要。

上記の小さい保存照合補足の再読取待ち。既存24caseの実結果合格を先取りせず、case/範囲の読取とroot実行結果を分ける。製品・正式Work/Git/Storeは変更していない。
