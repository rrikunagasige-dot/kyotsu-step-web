import fs from'node:fs';import path from'node:path';import{createHash}from'node:crypto';import zlib from'node:zlib';
const root='/workspace/scratch/6ff917b2ec4a/w046-ux05-full',out='/tmp/w046-ux05-full/r04',sha=b=>createHash('sha256').update(b).digest('hex');
const{operate}=await import(root+'/tools/textbook/operations.mjs');const{buildNestedTransformationPlan}=await import(root+'/tools/textbook/transformation/nested-lesson.mjs');const designRaw=fs.readFileSync(root+'/work/items/W-MATH-043-n0910-restart/NODE_DESIGN.json','utf8');const summary=[];
for(const code of['n09','n10']){const sourceRaw=fs.readFileSync(root+'/src/data/textbook/math/numbers/'+code+'Authored.json','utf8'),ir=JSON.parse(sourceRaw),assets=Object.fromEntries(ir.unit.sections.flatMap(s=>s.figures).map(f=>[f.src,sha(fs.readFileSync(path.join(root,'public',f.src)))])),plan=buildNestedTransformationPlan(sourceRaw,designRaw,ir.unit.unitId,assets),input={ir,transformationPlan:plan};let visible;
 for(const operation of['solution-validate','verify-ir','teaching-candidates','interaction-plan','construction-validate','layout-validate','construction-compile','visible-snapshots']){
  // The legacy generic teaching-candidates service has no native graph input;
  // native interaction candidates + explicit author teaching plan remain separate.
  if(operation==='teaching-candidates')continue;
  const r=operate(operation,operation==='layout-validate'?{layoutPlan:plan.layoutPlan,bindingContext:{nodeIds:plan.nodeDesign.map(n=>n.nodeId),partIds:plan.nodeDesign.flatMap(n=>n.parts.map(p=>p.id)),rowIds:plan.nodeDesign.flatMap(n=>n.rows.map(r=>r.id))}}:input);
  const bytes=JSON.stringify(r,null,2)+'\n';if(operation==='visible-snapshots'){visible=r;fs.writeFileSync(out+'/'+code+'-'+operation+'.json.gz',zlib.gzipSync(bytes));}else if(operation==='construction-compile')fs.writeFileSync(out+'/'+code+'-'+operation+'.json',JSON.stringify({...r,compiled:undefined,compiledHash:r.compiled?.compiledHash,rawSHA256:sha(bytes)},null,2));else fs.writeFileSync(out+'/'+code+'-'+operation+'.json',bytes);
  summary.push({code,operation,status:r.status,snapshotCount:r.snapshots?.length,candidateCount:r.candidates?.length,findings:r.findings,reason:r.reason});if(['FAIL','UNSUPPORTED'].includes(r.status))process.exitCode=1;
 }
 const report=JSON.parse(fs.readFileSync(out+'/../'+code+'-author-report.json'));const ids=report.changedNodeIds??report.changedNodes;const reviews=[];
 for(const id of ids){const snapshot=visible.snapshots.find(s=>s.visible.visible.some(n=>n.node.nodeId===id));const item=snapshot.visible.visible.find(n=>n.node.nodeId===id),publicState={node:item.node,rows:item.rows,parts:item.parts,resolved:item.resolved};reviews.push({id,visible:{initial:publicState,current:publicState},context:{phase:'pre-design',sourceRefs:[code+'Authored.json','NODE_DESIGN:'+sha(designRaw)],caseIds:['W046-UX05-main-inference','W046-UX05-resolved-math']}});}
 const requests=operate('solution-review',{reviews});fs.writeFileSync(out+'/'+code+'-meaning-requests.json',JSON.stringify(requests,null,2));console.log(code,summary.filter(r=>r.code===code).map(r=>[r.operation,r.status]),'meaning',requests.status,requests.reviews.length);if(requests.status==='FAIL')process.exitCode=1;
}
fs.writeFileSync(out+'/summary.json',JSON.stringify({designSha256:sha(designRaw),formalStoreReceipt:false,results:summary},null,2));
