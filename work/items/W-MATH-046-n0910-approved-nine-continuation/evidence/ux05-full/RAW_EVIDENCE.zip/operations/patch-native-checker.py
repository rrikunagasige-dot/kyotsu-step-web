from pathlib import Path
p=Path('/workspace/scratch/6ff917b2ec4a/w046-ux05-full/tools/textbook/layout/nested-run-measurements.mjs');s=p.read_text()
a='/** Validate complete source-bound browser runs; a partial geometry packet is insufficient. */'
helpers='''/** Exact learner DOM contract: there are no terminal memo rows in this reader.
 * Extras always use their source ID and readonly mode, including in history. */
export function expectedNestedReaderFormulas(node, visible, mode, prefix = '') {
  const result = visible.rows.filter(row => row.kind === 'math').map(row => {
    const keys = new Set([...row.partKeys, ...Array.from(row.template.matchAll(/\\{mirror:([^}]+)\\}/g), match => match[1])]);
    const parts = visible.parts.filter(part => keys.has(part.key));
    return { id: prefix + row.id, template: row.template, mode,
      parts: parts.map(part => ({ key: part.key, kind: part.prompt, role: part.role, choices: part.choices })),
      values: Object.fromEntries(parts.filter(part => part.value !== undefined).map(part => [part.key, part.value])),
      certifiedKeys: parts.filter(part => part.correct).map(part => part.key) };
  });
  if (node.equationNumber !== undefined && result.length) result.at(-1).equationTag = '(' + [node.equationNumber, ...(node.numberAliases ?? [])].join(' / ') + ')';
  return [...result, ...expectedNestedReaderExtras(node, visible)];
}
function expectedNestedReaderExtras(node, visible) {
  return visible.resolved ? (node.displayExtras ?? []).flatMap((extra, index) => extra.kind === 'math' ? [{ id: node.nodeId + '-extra-' + index, template: extra.latex, mode: 'readonly', parts: [] }] : []) : [];
}
export function expectedNestedReaderAuxiliary(compiled, finalView) {
  const currentStageId = finalView.visible.at(-1).node.stageId;
  const stageIndex = compiled.stages.findIndex(stage => stage.id === currentStageId);
  const previousStages = new Set(compiled.stages.slice(0, stageIndex).map(stage => stage.id));
  const item = node => finalView.visible.find(entry => entry.node.nodeId === node.nodeId);
  const auto = compiled.stages.map(stage => ({ stageId: stage.id,
    formulas: compiled.nodeDesign.filter(node => node.stageId === stage.id).flatMap(node => !node.parts.length
      ? expectedNestedReaderFormulas(node, item(node), 'interactive') : expectedNestedReaderExtras(node, item(node))) }));
  const history = compiled.nodeDesign.filter(node => previousStages.has(node.stageId)).flatMap(node => expectedNestedReaderFormulas(node, item(node), 'readonly', 'history-'));
  return { auto, history, currentStageId };
}

'''
assert a in s;s=s.replace(a,helpers+a)
s=s.replace("if (!Array.isArray(run.errors)", "if (!Array.isArray(run.httpErrors) || run.httpErrors.length || !Array.isArray(run.networkFailures) || run.networkFailures.length) reject('NESTED_HTTP_NETWORK_FAILURE', at);\n    if (!Array.isArray(run.errors)")
start=s.index('    const expectedFor = (node, visible, mode, prefix=\'\') => {');end=s.index('    for (const packet of packets)',start);s=s[:start]+s[end:]
s=s.replace("|| !Array.isArray(packet.formulas) || !packet.formulas.length", "|| !Array.isArray(packet.formulas)")
a="const node=compiled.nodeDesign.find(n=>n.parts.some(p=>p.id===packet.part)), visible=snapshot.visible.visible.find(n=>n.node.nodeId===node.nodeId), currentStage=snapshot.visible.visible.at(-1).node.stageId;\n      bindFormulas(packet.formulas,expectedFor(node,visible,visible.resolved&&node.stageId!==currentStage?'readonly':'interactive'),at+':'+packet.part+':'+packet.state);"
b="const node=compiled.nodeDesign.find(n=>n.parts.some(p=>p.id===packet.part)), visible=snapshot.visible.visible.find(n=>n.node.nodeId===node.nodeId);\n      if (packet.stageId !== node.stageId) reject('NESTED_PACKET_STAGE_BINDING', at+':'+packet.part);\n      // The answer callback keeps the owner's stage active, including its filled packet.\n      bindFormulas(packet.formulas,expectedNestedReaderFormulas(node,visible,'interactive'),at+':'+packet.part+':'+packet.state);";assert a in s;s=s.replace(a,b)
start=s.index('    const finalView=snapshots.at(-1).visible, currentStage=');end=s.index('\n  }\n  return { status:',start)
s=s[:start]+'''    const auxiliary = expectedNestedReaderAuxiliary(compiled, snapshots.at(-1).visible);
    const autoPackets = run.auxiliaryPackets?.filter(packet => packet.kind === 'auto') ?? [];
    if (autoPackets.length !== auxiliary.auto.length || new Set(autoPackets.map(packet => packet.stageId)).size !== auxiliary.auto.length || autoPackets.some(packet => !auxiliary.auto.some(stage => stage.stageId === packet.stageId))) reject('NESTED_AUTO_STAGE_COVERAGE', at);
    const checkAuxiliary = (packet, expected, kind) => {
      bindFormulas(packet.formulas, expected, at+':'+kind);
      if (packet.viewport !== run.width || !finite(packet.pageWidth) || packet.pageWidth > run.width + 1) reject('NESTED_AUXILIARY_VIEWPORT', at+':'+kind);
      for (const formula of packet.formulas ?? []) {
        formulaCount++;
        const verified = checkNestedMeasurements(formula.geometry);
        if (verified.status !== 'PASS' || formula.geometry.status !== 'PASS' || formula.font !== '18px' || formula.status !== 'MEASURED' || formula.overflow === 'true') reject('NESTED_AUXILIARY_GEOMETRY', { at, kind, id: formula.id, findings: verified.findings });
      }
    };
    for (const stage of auxiliary.auto) {
      const packets = autoPackets.filter(packet => packet.stageId === stage.stageId);
      if (packets.length === 1) checkAuxiliary(packets[0], stage.formulas, 'auto:'+stage.stageId);
    }
    const historyPackets = run.auxiliaryPackets?.filter(packet => packet.kind === 'history') ?? [];
    if (historyPackets.length !== 1) reject('NESTED_AUXILIARY_COVERAGE', at+':history');
    else {
      if (historyPackets[0].stageId !== auxiliary.currentStageId) reject('NESTED_HISTORY_STAGE_BINDING', at);
      checkAuxiliary(historyPackets[0], auxiliary.history, 'history');
    }''' +s[end:]
p.write_text(s)
