import sys,json,subprocess,hashlib
from pathlib import Path
from types import SimpleNamespace
root=Path('/workspace/scratch/6ff917b2ec4a/w046-ux05-release-frozen');sys.path.insert(0,str(root/'workflow'))
from runner import code_operation
from impact import inventory
baseline='a1b6c123eb9076ffcb3153684b328a1c12aa2b2f';candidate='691d3d160493bf684ca8a31a22476d31d98caeec'
paths=subprocess.check_output(['git','ls-tree','-r','--name-only',baseline,'src','public','package.json','pnpm-lock.yaml'],cwd=root,text=True).splitlines();allowed={x['path']for x in json.load(open('/tmp/w046-ux05-full/source-upload.json'))};allowed.add('src/components/textbook/ConstructionLessonReadingFlow.tsx');protected={}
for p in paths:
 if p not in allowed:protected[p]=hashlib.sha256(subprocess.check_output(['git','show',baseline+':'+p],cwd=root)).hexdigest()
# Read-only adapter supplies explicit operation inputs; no Runtime or Store is created.
rt=SimpleNamespace(root=root,state=lambda work:{'candidate_sha':candidate})
result=code_operation(rt,'W-MATH-046','S20',{'protectedManifest':protected})
rows=[]
for code in ['n09','n10']:
 old=json.loads(subprocess.check_output(['git','show',baseline+':src/data/textbook/math/numbers/'+code+'ConstructionCompiled.json'],cwd=root));new=json.load(open(root/('src/data/textbook/math/numbers/'+code+'ConstructionCompiled.json')));report=json.load(open('/tmp/w046-ux05-full/'+code+'-author-report.json'));changes=report.get('changedNodeIds',report.get('changedNodes'))
 oldNodes={n['nodeId']:n for n in old['nodeDesign']}
 for n in new['nodeDesign']:
  changed=n['nodeId']in changes
  if not changed:assert n==oldNodes[n['nodeId']],n['nodeId']
  rows.append({'block_id':n['nodeId'],'artifact':code+'ConstructionCompiled.json#'+n['nodeId'],'version':candidate,'status':'AFFECTED'if changed else'NOT-AFFECTED','phase':'post-fix','originFinding':'W046-UX05-main-inference','rootCauseSignature':'main-judgment-auto-or-trivial-blank','approvedCreationWork':'P-W046-UX-05','evidence_refs':['source:'+candidate,'r07:'+code]})
raw={'protected':{'directExistingOperation':'workflow.runner.code_operation S20','status':result['status'],'baseline':baseline,'candidate':candidate,'fileCount':len(protected),'manifest':protected},'impact':{'directExistingOperation':'workflow.impact.inventory','status':'NEEDS_AI_REVIEW','rows':inventory({'plan':{'impact_inventory':rows}},{}),'counts':{'all':len(rows),'changed':sum(r['status']=='AFFECTED'for r in rows),'unchanged':sum(r['status']=='NOT-AFFECTED'for r in rows)}},'formalStoreReceipt':False}
Path('/tmp/w046-ux05-full/protected-impact.json').write_text(json.dumps(raw,ensure_ascii=False,indent=2)+'\n');print(result['status'],len(protected),raw['impact']['counts'])
