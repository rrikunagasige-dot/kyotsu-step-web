from pathlib import Path
import json,hashlib
b=Path('/tmp/w046-ux05-full/r07-final');p=b/'n09-requests.json';D=json.loads(p.read_text());pre=json.loads(Path('/tmp/w046-ux05-full/r04/n09-responses-b.json').read_text());math={r['id']:r['response'] for r in pre['reviews']};reviews=[];images=[]
for entry in D['reviews']:
 q=entry['request'];nid=entry['id'];assert q['phase']=='post-fix' and q['profile']=='construction-layout'
 evid={e['id']:e for e in q['evidenceManifest']}
 for e in evid.values():
  ep=Path(e['path']);assert ep.exists() and hashlib.sha256(ep.read_bytes()).hexdigest()==e['sha256'];assert e['sourceSHA']==D['sourceSHA']
  if e['kind']=='image':images.append({'path':str(ep),'sha256':e['sha256'],'nodeId':nid,'state':e['state'],'width':320})
 response={k:math[nid][k] for k in ['learnerDecision','reasonToProceed','nextWholeState','misconception','reducedSupportVariant']}
 response.update(phase=q['phase'],requestHash=q['requestHash'],reviewer='/root/w046_render_review — N09教材/設計の非作者、共有renderer作者（共有実装の独立PASSはAへ委任）',availableInformation='新691dの320原PNGを初期/完成で実見。'+math[nid]['availableInformation']+' R04の数学根拠だけを継承し、今回の見た目・消込み・行の可読性は新画像と実DOM幾何で別に確認した。',findings=[],reviewRows=[],caseDispositions=[
 {'caseId':'W046-UX05-main-inference','status':'APPLIED','evidence':'新sourceの実初期/完成画像で、一般則を教える提示行、本人の具体適用/必要計算、正答後の導出を区別。既出参照/AUTOを新回答と数えず、Q08の必要6計算を保持。'},
 {'caseId':'W046-UX05-resolved-math','status':'APPLIED','evidence':'要求のN09 math行を実画像/同source DOMgeometryで確認し、正答後の値と括弧/根号の意味対象が読める。旧Q08の余白所見は691d新画像で解消を確認。共有renderer実装自体の独立判定はAの別報告で、このB判定はN09教材/表示統合に限定。'}],automaticAcceptance=False,scope='要求された320の14node/71row。1440実見は後続の別追記であり、本ファイルだけで全幅/全体受入を認定しない。')
 for scope in q['reviewScope']:
  view=q['visible']['initial' if scope['state']=='initial' else 'current'];row=next(r for r in view['rows'] if r['id']==scope['rowId']);isQuestion=scope['state']=='initial' and bool(row['partKeys']);isText=row['kind']=='text'
  if isQuestion:learner='この未確定行で行う本人判断：'+math[nid]['learnerDecision'];copy='初期本文に具体的な正答は確定表示されていない。一般則/認定済み値は使用し、現在の対象へ適用する。';placement='必要な条件/一般則の後に当該穴と選択肢が続く。別の基本小問へ過剰分解していない。'
  elif scope['state']=='initial':learner='この行は条件/一般則/認定済み結果の提示で、新しい採点判断そのものではない。';copy='一般形または既知の対象を示す。後続の具体的な中項/平方根値/小数部分を確定値として先に与えていない。';placement='現在の具体的適用の前に必要な説明として置かれ、式と対象が対応する。'
  else:learner='この行は回答後の確定結果/根拠、またはAUTO参照であり新たな採点小問ではない。';copy='要求された完成stateの認定済み情報を表示している。過去回答の数え直しや、未解決の後段を飛ばす認定ではない。';placement='本人の判断または既認定参照の後に導出を残す。補助量から本体へ戻る箇所は完全左辺/数学対象を維持。'
  quote=row['id'];assert quote in json.dumps(q['visible'],ensure_ascii=False)
  response['reviewRows'].append({'rowId':scope['rowId'],**({'partId':scope['partId']}if 'partId'in scope else {}),'state':scope['state'],'decision':'ADOPT','learnerDecision':learner,'availableInformation':('実text説明行：' if isText else '実math行：')+row['template'],'copyRisk':copy,'nextUse':math[nid]['nextWholeState'],'misconception':math[nid]['misconception'],'prosePlacement':placement,'quoteOrMathRef':quote,'evidenceRefs':[scope['imageRef'],scope['geometryRef']]})
 if nid=='n09-q07-negation':response['nonblockingObservations']=[{'location':'assumptionParts（71math/text row scopeとは別）','description':'320で条件末尾の句点だけが次行に残る。式の条件は読める。rootは承認本文を無断短縮せずnonblocking観察として保持する判断。数学/後続解放の欠陥とはしない。'}]
 reviews.append({'id':nid,'response':response})
assert len(reviews)==14 and sum(len(x['response']['reviewRows'])for x in reviews)==71
out=b/'n09-responses-b.json';out.write_text(json.dumps({'sourceSHA':D['sourceSHA'],'requestFileSHA256':hashlib.sha256(p.read_bytes()).hexdigest(),'reviews':reviews},ensure_ascii=False,indent=2)+'\n');(b/'n09-images-reviewed-b.json').write_text(json.dumps({'sourceSHA':D['sourceSHA'],'manualView':'view_imageで320全26原PNGを新sourceとして実見済み。1440未含有。','images':images},ensure_ascii=False,indent=2)+'\n');print('responses',hashlib.sha256(out.read_bytes()).hexdigest());print('images',len(images))
