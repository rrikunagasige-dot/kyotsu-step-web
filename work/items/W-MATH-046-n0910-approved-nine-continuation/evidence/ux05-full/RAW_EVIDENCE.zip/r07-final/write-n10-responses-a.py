import json,pathlib,hashlib
r=pathlib.Path('/tmp/w046-ux05-full/r07-final');p=r/'n10-requests.json';req=json.load(open(p));pre=json.load(open('/tmp/w046-ux05-full/r04/n10-responses-a.json'));arguments={x['id']:x['response'] for x in pre['reviews']}
visual={
'n10-q10-coefficients':('初期は共通因子を集める式全体の空欄と四候補。完了は(2＋5)√2の式のあと係数7の計算へ続き、同じ根号を保つ主判断が単なる7入力の前にある。','初期の式番号下置きは空欄/候補を妨げない。691d完了画像では行間の40px残留が消え、collect→sumの同じ導出が通常間隔でつながる。'),
'n10-q11-formula':('一般差平方公式を見ながら、符号と係数と二根号の因子を含む中項全体を作る。未回答は44pxの操作域、完了は−2√2√3という通常の項へ戻り、−一字の小問ではない。','320では元の平方と次行の展開を等号でつなぐ。根号/括弧の意味を保ち、完了に回答枠の伸び残りはない。一般公式もtyped mathで表示され、本文折返しによる符号の消失はない。'),
'n10-q13-identity':('元の和差積と、相殺する具体交差項の組の四候補が初期に見える。組の順序は問わず一つの候補の中で二行表示。完了後に展開と相殺を出すので、主たる相殺判断を先にAUTO提示しない。','足場の選択buttonは完了後消え、通常の展開式へ戻る。320の展開は等号と和の意味境界で折り返し、根号の内部や同じ候補を別buttonへ分断しない。'),
'n10-17':('ここは前段の非零認定を使う値保持の途中式で、現在partはない。分子/分母をまとめることを新しい生徒回答として捏造せず、次の分子分配判断は残す。','実画像は上下へ同じ非零因子を掛けた一つの分数変形を示す。通常の分数/根号/括弧で、空の操作欄や認定メモを重ねない。'),
'n10-q19-distribute':('初期は対象を分子√3(√3−√2)と固定して、分配後の式全体を選ぶ。完了は外の√3が両項へ掛かった式であり、片方の符号や−1だけの小問にしない。','分母から分子へ対象を本文で切り替え、分子の完全左辺と次行=で接続する。括弧/根号は完了後通常寸法で、式番号は可視末尾の導出行に対応する。'),
'n10-19':('既認定平方3を本文で再利用し、異なる根号の積に必要な2×3だけを本人が計算する。完了では分子の結果を元の分数へ戻し、値を同一の対象として接続する。','691d完了ではproduct→元分数returnの間の余分な40pxがなくなった。元分数の完全左辺があるため、分子の補助式と元分数を偽の等号で結ばない。'),
'n10-q20-factor':('初期に正の因子を使う本手順と別解を区別し、因子を選ぶ主判断を残す。完了では平方4/3・正性・非零・値保持の理由が順に認定され、factorだけで他の検証を飛ばさない。','初期の未回答因子は中立の大きい括弧/操作域を保ち、完了の二因子は通常の括弧へ縮まる。証明の比較行は意味境界で改行、c≠0の直後に理由が連続する。'),
'n10-20':('分子の差どうしの積と分母の和差積を区別し、分数全体へ対応する公式を本人が選ぶ。分母平方を既認定4/3へ代入した後も、分子中項を次に本人へ残す。','未回答の全分数を一つの操作として扱い、完了後は通常の分子平方/分母平方差と4−3へ戻る。同一分数の等式鎖であり、括弧や根号の44px残りはない。'),
'n10-q21-expand':('初期に一般公式と既認定4/3を示し、具体的な中項全体を未回答にする。完了は−4√3の符号込み中項で、旧P/Q/Kの単純な再入力や−だけの回答ではない。','元の分子の平方を主語とした行がそのまま通常の三項式へ変わる。初期の操作枠が完了に残らず、通常括弧/根号/指数で読める。'),
}
reviews=[];asset_count=0
for item in req['reviews']:
 q=item['request'];nid=item['id'];a=arguments[nid]
 for e in q['evidenceManifest']:
  f=pathlib.Path(e['path']);assert hashlib.sha256(f.read_bytes()).hexdigest()==e['sha256'];asset_count+=1
 rows=[]
 for s in q['reviewScope']:
  v=q['visible']['initial' if s['state']=='initial' else 'current'];vr=next(z for z in v['rows'] if z['id']==s['rowId']);row=dict(s);row.pop('imageRef');row.pop('geometryRef')
  math=vr.get('template',vr.get('formula'));observation=visual[nid][0];place=visual[nid][1]
  row.update(decision='ADOPT',learnerDecision=observation,availableInformation=('初期の実画像/可視本文・条件・現在式・候補を用いる。' if s['state']=='initial' else '完了の実画像と認定後の可視行を用いる。')+' 対象行は '+math,copyRisk='この行の候補は未認定の選択肢として並び、確定本文へ正答を先書きしない。' if s['state']=='initial' else '認定後の式であることをpublic currentのcorrect/valueと実画像で確認。未回答時へ同じ完成行を逆流させない。',nextUse=a['nextWholeState'],misconception=a['misconception'],prosePlacement=place,quoteOrMathRef=s['rowId'],evidenceRefs=[s['imageRef'],s['geometryRef']]);rows.append(row)
 row_uses={
   'ux05-square-left':'この2²=4を、正の2と√3の平方比較の左値へ使う。初期の因子選択だけでこの値を完成扱いにしない。',
   'ux05-square-root':'平方根の定義による(√3)²=3を右値へ使い、後のq21でもこの認定resultを参照する。',
   'ux05-compare':'2>0、√3>0と平方4>3から2>√3を得て、差2−√3の正性へ接続する。平方値比較だけで非零の理由を飛ばさない。',
   'ux05-sign':'確定した2−√3>0から、掛ける因子cが0でないことへ進む。',
   'ux05-nonzero':'c≠0をc/c=1の値保持へ使い、上下へ同じ因子を掛ける操作の理由をつなぐ。',
   'ux05-reason':'非零と分母積の有理性の理由がまとまったので、次は元分数の上下へその因子を掛ける。',
   'ux05-collect':'共通根号を保った係数和の式を、次の係数2＋5の必要計算に使う。',
   'ux05-sum':'7√2を元の二根号の和の結論として使う。別問題へ根拠なしに同じ係数を運ばない。',
   'ux05-expand':'負と正の交差項が同じ大きさであることを確認し、相殺して平方差へ戻す。',
   'ux05-cancel':'残った(√7)²と(√2)²の平方値と差を計算する次の段階へ使う。',
   'ux05-known-squares':'確定平方を代入した分母4−3へ戻り、分子の差平方の中項は次に本人が作る。',
   'ux05-product':'分子の根号積の結果を、分母1の元分数へ完全左辺付きで戻す。',
   'ux05-return':'有理化した元の分数が3−√6と結論したことを保持する。次の別問題の分数へ偽の等式で連結しない。',
  }
 for reviewed in rows:
  suffix=reviewed['rowId'].split('::')[-1]
  if suffix in row_uses:reviewed['nextUse']=row_uses[suffix]
 findings=[]
 if nid in ['n10-q10-coefficients','n10-19']:
  scope=next(s for s in q['reviewScope'] if s['state']=='complete');v=next(z for z in q['visible']['current']['rows'] if z['id']==scope['rowId'])
  findings.append(dict(problemId=nid,stepId=scope['rowId'],state='complete',quoteOrMathRef=scope['rowId'],reason='旧ba2eの初期tag-below状態が、式番号の移動後も40px paddingとして完了行へ残った。新691dの同一行の実画像で過剰な余白の解消を確認した。',affectedRefs=[scope['rowId'],nid,'TaggedMathRow'],resolution='VERIFIED_FIXED',evidenceRefs=[scope['imageRef'],scope['geometryRef']],originalDisposition='REVISE',originalSource='ba2e1d8b00c7d7eb113cb9d828ec8b495adcf444',fixedSource=req['sourceSHA']))
 response={k:a[k] for k in ['reasonToProceed','misconception','reducedSupportVariant']}
 response.update(phase=q['phase'],requestHash=q['requestHash'],reviewer='/root/w046_source_review — N10教材/設計・共有rendererの非作者（N09作者、同じmodel/履歴共有）。実public/原画像を読取。',learnerDecision=visual[nid][0],availableInformation='source691dの320初期/完了の実画像（AUTOは完了一枚）を実見し、可視本文/条件/現在式/候補と34assetのhashを照合。作者理由欄や私有expectedを可視根拠にしない。',nextWholeState=a['nextWholeState'],findings=findings,reviewRows=rows,caseDispositions=[dict(caseId='W046-UX05-main-inference',status='APPLIED',evidence=visual[nid][0]),dict(caseId='W046-UX05-resolved-math',status='APPLIED',evidence=visual[nid][1]+' 対象のMEASURED/18px/overflow falseと実source-bound geometryを確認。')],scope='指定320の9request/31row-stateの非作者意味/表示/操作審査。1440と全四幅の実結果は別補足で確認し、この応答だけで本人受入/公開/Goldにしない。',automaticAcceptance=False,formalProof=False,proofStatus='AI_ARGUMENT_REVIEWED')
 reviews.append(dict(id=nid,response=response))
out=dict(requestFileSHA256=hashlib.sha256(p.read_bytes()).hexdigest(),sourceSHA=req['sourceSHA'],reviews=reviews,inspectedImages=17,evidenceAssetsHashed=asset_count)
(r/'n10-responses-a.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(len(reviews),sum(len(x['response']['reviewRows']) for x in reviews),asset_count)
