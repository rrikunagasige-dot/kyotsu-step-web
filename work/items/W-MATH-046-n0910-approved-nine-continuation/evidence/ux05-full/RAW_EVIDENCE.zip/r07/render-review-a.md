# UX05 full N10 R07 非作者実画像審査 A

担当 /root/w046_source_review。N10教材・共有rendererの非作者（N09作者、同じmodel/履歴共有）。R07の実public stateと実画像を根拠にする。旧pre-design審査は補助であり、実画像の代用にしない。

## 初回：source ba2e1d8b

320pxの変更9nodeの初期/完了画像17枚（0part n10-17はauto-complete一枚）を全件実見した。原9request/31row-stateのpublic条件・現在式・候補も読取した。

数学/主判断について、係数を集める式・符号込み中項・相殺交差項の組・分子全体の分配・分数全体への公式適用は本人操作として見える。根号/括弧に正答済み44px操作枠の伸び残りはない。未回答の因子や根号内は中立の44px操作域を保つ。q13の組は一候補一button内で二行、非零因子のq20は正の手順という指定と別解を区別している。q21の4/3は前段認定値として本文に明示され、中項だけが未回答である。数学上の新blockerは現時点で見つからない。

### Original REVISE：式番号移動後の40px残留余白

320のn10-q10-coefficients completeでは、同一導出のcollect行とsum行の間に余分な約40pxが残る。n10-19 completeのproduct行とreturn行にも同型が見える。初期に式番号が下置きになった行が、次行の解放後にnumberなしになってもplacement.belowを保持し、CSSのtag-below padding-bottom:40pxが残ることをsourceで確認した。式frameだけの幾何PASSではこの行余白を検出していなかった。

原requestを `n10-requests-original.json`、原画像を `original-n10-q10-complete.png`（SHA f3a6ad518f86123c3d481be1e3390707e535751a82922b8f3fb2192d033891a5）と `original-n10-19-complete.png`（SHA 8d80c82692e08144544f798b928f2ca767d38e5fac026b8270d4b856da51491d）へコピー保持した。元requestのimage SHAと実byteが一致することを確認した。

rootはsource691d3d16へ最小class条件 `number!==undefined && placement.below` を補修し、tagなしrowのclass/paddingBottom=0を実DOM collectorへ追加して四幅を再実行中。これはroot報告であり、新sourceの実画像再読前に実行合格へ変更しない。旧REVISEを保持し、更新requestと画像確認後にfinal応答へ追記する。

## G2の静的補完

active N10r5とR4不変snapshotのcompiled nodeDesignを承認JSONのKEEP指定に従って比較し、KEEP36nodeは全object一致を直接確認した。これを変更9実画面＋全状態browserと組み合わせ全45nodeへ対応する。KEEP36が不変であることを、今回私が全36を新画像で実見したという意味へ変えない。

## 現在の結論

旧sourceの表示余白はREVISE、新sourceの320/1440実画像と31scopeの再確認待ち。全数理の機械証明、本人総合受入、公開許可・Gold/fitは主張しない。保存/移行のroot統合は別の非作者ソース/collectorレビューと実24caseへ結ぶ。
